using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class Codiguito : MonoBehaviour {
  void Start () {
    print("ola kéasé");
  }
}
